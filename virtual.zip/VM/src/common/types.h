#ifndef __TYPES_H
#define __TYPES_H

#define bool int
#define false 0
#define true 1

#endif