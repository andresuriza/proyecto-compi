#ifndef __STDLIB_H
#define __STDLIB_H

#include "types.h"

bool streq(char* string1, int str1len, char* string2, int str2len);

#endif