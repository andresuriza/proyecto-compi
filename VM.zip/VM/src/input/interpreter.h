#ifndef INTERPRETER_H
#define INTERPRETER_H

void interpret_vgraph(const char* unused_path);

#endif

