#ifndef TYPES_H
#define TYPES_H


#include <stdint.h>
#include <stddef.h>  // para size_t, NULL, etc.

#endif /* TYPES_H */

